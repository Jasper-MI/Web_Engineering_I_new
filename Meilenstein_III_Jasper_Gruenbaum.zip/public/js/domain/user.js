export class User {
    constructor(userId, firstName, lastName, password) {
        this.userId = userId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.password = password;
    }
}
